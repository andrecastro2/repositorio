valor_em_dolar: float = float(input("INFORME O VALOR RECEBIDO EM U$: "))
preco_real: float = 5.67

total_em_real: float = valor_em_dolar * preco_real

print(f"Você tem R$ {total_em_real:.2f}")
