lucroa: float = 0.45
lucrob: float = 0.30

valor_produto: float = float(input("Informe o valor do produto: "))
valor_final_com_lucro: float = 0.0

if valor_produto < 20:
    percentual_real: float = valor_produto * lucroa
    valor_final_com_lucro = valor_produto + percentual_real
else:
    percentual_real: float = valor_produto * lucrob
    valor_final_com_lucro = valor_produto + percentual_real

print(f"O valor final do produto é: R$ {valor_final_com_lucro:.2f}")
