# Programa para copiar o valor da variável A para a variável B

# Atribuindo valores
A = 10  # você pode trocar por qualquer valor
B = 0   # valor inicial de B

# Exibindo valores antes da cópia
print("Antes da cópia:")
print("A =", A)
print("B =", B)

# Copiando o valor de A para B
B = A

# Exibindo valores depois da cópia
print("\nDepois da cópia:")
print("A =", A)
print("B =", B)
