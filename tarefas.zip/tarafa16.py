... crie um menu de opcoes para o usuario navegar do sistema 
o meunu tem que ter as seguintes opcoes 
a - ver saldo
b - depositar
c - sacar,
d encerrar Conta,
x - sair do sistema,
caso ele escolha ua das opcoes corretas, informe ele em qual parte do sistema ele esta 
exemplo : A = seu saldo e R$ 100000,


