num1: int = 19
num2: int = 17
idade: bool = 19
resultado: bool = False
resultado = idade > 18
print(resultado)


