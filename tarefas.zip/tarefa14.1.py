vA: str = input("informe o valor:")
vB: str = input("informe o valor 2 :")

vB = vA
print(vB)
