print("calculadora proz")

n1: int = 0 
n2: int = 0
total: int = 0 

n1 = input ( "digite o primeiro numero:")
n2 = input ( "digite o segundo numero:")
total = float n1 + n2
print(" a soma e:",total)
