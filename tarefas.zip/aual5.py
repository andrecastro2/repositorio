# Solicita os dados ao usuário
nome = input("Digite seu nome: ")
cidade = input("Digite sua cidade: ")
idade = input("Digite sua idade: ")

# Exibe as informações formatadas
print(f"Eu sou {nome}, moro em {cidade}, e tenho {idade} anos.")
