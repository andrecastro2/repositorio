nota: float = float(input("informe a nota do abencoado:"))

if nota > 6.0:
    print("O Aluno esta aprovado.")
elif nota < 4.0:
    print("O Aluno esta reprovado")
else:
    print(" aluno")


