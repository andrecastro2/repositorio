# Define a senha padrão
senha_padrao = "admin@2025"

# Solicita a senha do usuário
senha_usuario = input("Digite a senha: ")

# Verifica se a senha está correta
if senha_usuario == senha_padrao:
    print("Autenticação realizada com sucesso")
else:
    print("Senha inválida")