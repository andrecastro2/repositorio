valor_em_real: float = float(input("INFORME O VALOR EM REAIS (R$): "))
preco_dolar: float = 5.67  # 1 dólar = 5.67 reais

total_em_dolar: float = valor_em_real / preco_dolar

print(f"Você tem U$ {total_em_dolar:.2f}")