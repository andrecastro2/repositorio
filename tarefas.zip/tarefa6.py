nota1: float = 30 
nota2: float = 15
nota3: float = 19

media = (nota1+nota2+nota3) / 3

print("a media da nota e :", media)

