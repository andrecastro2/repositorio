idade: int = int(input("digite sua idade:"))
if idade >= 18 :
    print("Bem vindo a festa!!!")
else:
    print("nao pode entrar Maria")