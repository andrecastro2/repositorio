dia_semana: int = int(input("Informe o número do dia: "))

match dia_semana:
    case 1:
        print("DOMINGO")
    case 2:
        print("SEGUNDA-FEIRA")
    case 3:
        print("TERÇA-FEIRA")
    case 4:
        print("QUARTA-FEIRA")
    case 5:
        print("QUINTA-FEIRA")
    case 6:
        print("SEXTA-FEIRA")
    case 7:
        print("SÁBADO")
    case _:
        print("Número inválido! Informe um número de 1 a 7.")
