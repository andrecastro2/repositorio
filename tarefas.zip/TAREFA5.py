preco_maca: float = 1.50
desconto: float = 5.00

quantidade_maca: float = float(input("Informe a quantidade: "))
valor_compra: float = quantidade_maca * preco_maca

if valor_compra > 20:
    valor_compra = valor_compra - desconto

print(f"O valor da compra deu: R$ {valor_compra:.2f}")
