figura1: ("quadrado")
figura2: ("retangulo")

