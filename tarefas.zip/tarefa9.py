'''negativo ou positivo? - atividade 9 '''
num = int(input("insira um numero:"))

if num < 0 :
    print("numeropositvo")
else : 
    print("numero negativo")