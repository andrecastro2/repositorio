# Dicionário com os conceitos e seus significados
tabela_conceitos = {
    "A": "Excelente desempenho",
    "B": "Bom desempenho",
    "C": "Desempenho satisfatório",
    "D": "Desempenho abaixo do esperado",
    "E": "Desempenho insuficiente"
}

# Solicita o conceito do aluno
conceito = input("Informe o conceito do aluno (A, B, C, D, E): ").strip().upper()

# Verifica se o conceito existe na tabela
if conceito in tabela_conceitos:
    print(f"Significado do conceito '{conceito}': {tabela_conceitos[conceito]}")
else:
    print("Erro: conceito inexistente!")

