print("Calculadora Proz")

# Declarando variáveis
n1: int = 0
n2: int = 0
n3: int = 0
n4: int = 0
n5: int = 0
n6: int = 0
n7: int = 0
n8: int = 0
total: int = 0 
total1: int = 0 
total2: int = 0 
total3: int = 0 




# Obtendo entrada do usuário e convertendo para float
n1 = int(input("Digite o primeiro número: "))
n2 = int(input("Digite o segundo número: "))
n3 = int(input("Digite o terceiro número: "))
n4 = int(input("Digite o quatro número: "))
n5 = int(input("Digite o quinta número: "))
n6 = int(input("Digite o sexto número: "))
n7 = int(input("Digite o setimo número: "))
n8 = int(input("Digite o oitava número: "))

# Realizando a soma
total = n1 + n2
total1 = n3 - n4
total2 = n5 * n6
total3 = n7 / n8

# Exibindo o resultado
print("A soma é:", total)
print("A soma é:", total1)
print("A soma é:", total2)
print("A soma é:", total3)



